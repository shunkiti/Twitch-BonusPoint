■使い方
1. twitch-bonuspoint.exeを実行
2. Edgeのアドレスバーに「edge://version/」を入力
　-プロファイル パス「User Data\」までの値を「User Data Directory」へ入力
　-プロファイル パス「\」以降の値(DefaultやProfile~)を「Profile Directory」へ入力
3. Edgeのアドレスバーに「edge://settings/system/systemSubPage」を入力
　-スタートアップブーストをオフに
4. Edgeをすべて閉じる
5. チャンネルボーナスを自動で取得したいチャンネルのURLを入力

■注意点
・起動ボタン押下時に既にEdgeが起動しているとエラーが発生するので、閉じておいてください
　(バックグラウンドでよく起動されているので、もし起動ボタン押下後Edgeが立ち上がらない場合は要確認)
・実行中は別のブラウザ(Chrome,Firefox等)を使ってください。